<?php
/*
*Plugin Name: CMS7 Pokemon_Api
*Description: CMS7 Pokemon_Api randomizer
*Author: Paulina Abarca Jara
*/


//Ett ny widget som heter Pokemon Api ska regristeras 
add_action( 'widgets_init', function() {
    register_widget( 'Pokemon_Api' );
});

class Pokemon_Api extends WP_Widget { //Här difinerar jag klassen för min widget med namnet Pokemon_api
    public function __construct() {  //En function skapas för min konstruktor som jag sedan kan redigera och ge lite style till
        parent::__construct(
            'pokemon_api',  //Här sitter själva id för min widget
            'CMS7 Pokemon_Api', // samt dens namn, samma namn som mappen där den  sitter i
            array('description' => 'Pokemon funktioner för ett API-anrop i en widget.') //En liten beskrivning på vad min widget ska göra, samma discription som längst upp
        );
        wp_enqueue_style( 'Pokemon_api_CSS', plugins_url( '/pokemon-api-style.css', __FILE__ ) );  // Här kopplar jag min widget med andra filen jag skapat, alltså css stil mappen
    }
//Denna ska visa upp min widget i min webbsida.
    public function widget($args, $instance) {
        extract($args);  //Alla argument ska tas från min widget
    
        // Jag ska generera ett random Pokémon ID mellan nr 1 och 898, de olika pokemon som finns.
        $random_pokemon_id = rand(1, 898);
        
        // Här skapar jag (API)anropet för med koppling till den randomiserade pokemon id. Funkar vid varje reload också!
        $url = "https://pokeapi.co/api/v2/pokemon/{$random_pokemon_id}";
        $contents = file_get_contents($url);  //Ett Json content ska hämtas från de api jag hämtat.
        $contents = json_decode($contents, true); //min kod ska konvertera json till en array
    
        //Widgeten kommer visas så som den defineras av temat. 
        echo $before_widget; 
        if (!empty($instance['title'])) {  // Vi har satt en titel som kan sättas för min widget när den ska läggas in.
            echo $before_title . $instance['title'] . $after_title;
        }
    //Här kontrollerar vi med "if" att om api svaret är tomt så ska den få ett error
        if (!$contents) {  
            echo '<div class="pokemon-card error"><br>Error. No response from the API.</div>';
        } else {
            //Om ej tomt så ska den koppla sig till stilmallen och göra en pokemoncard enligt style.
            echo '<div class="pokemon-card">';
    
        // ------HÄR BÖRJAR ALLA POKEMON SPECIFIKATIONER ------

            $pokemon_image_url = $contents['sprites']['front_default']; // Här väljer jag att den ska hämta en bild till den passande pokemon
            if ($pokemon_image_url) {  // Bilden hämtas från api sidan
                echo '<div class="pokemon-image"><img src="' . esc_url($pokemon_image_url) . '" alt="' . ucfirst($contents['name']) . '" /></div>';
            }
    
            // Här sätter jag koden för att namnet och id på pokemonet ska visas
            $pokemon_name = ucfirst($contents['name']); //namnet hämtas, där första bokstaven är stor (ucfirst).
            $pokemon_id = $contents['id'];  //id hämtas
            echo '<div class="pokemon-info">';  //Sätter in den i pokemon info spalten i css
            echo '<h3>' . $pokemon_name . ' (#' . $pokemon_id . ')</h3>'; //placeras såhär
    
            // Här hämtas vikten och längden på pokemonet.
            $pokemon_height = $contents['height'] / 10; // Konverterar från decimeter till meter.
            $pokemon_weight = $contents['weight'] / 10; // Konverterar från hektogram till kilogram för att göra det lättare att läsa
            echo '<p><strong>Height:</strong> ' . $pokemon_height . ' meters</p>'; // Här beskrivs dem
            echo '<p><strong>Weight:</strong> ' . $pokemon_weight . ' kg</p>';  //beskrivs
    
            // En rad där förmågan eller abilities ska stå, alltså deras krafter
            echo '<p><strong>Abilities:</strong><ul>'; // skapar en p tagg med bold text för abilities
            foreach ($contents['abilities'] as $ability) { // hämtar abilities från min content api
                echo '<li>' . strip_tags($ability['ability']['name']) . '</li>'; // namnet på själva abilitien
            }
            echo '</ul></p>';
    
            // Visa upp pokemons typ, alltså fire,water,grass osv
            echo '<p><strong>Types:</strong><ul>'; // en titel skapas med namnet types
            foreach ($contents['types'] as $type) {  // HÄmtar types från min content api
                echo '<li>' . strip_tags($type['type']['name']) . '</li>'; //och sedan displayar det som förra
            }
            echo '</ul></p>';
    
          // Kommer visar Pokémon-statistik.
            echo '<p><strong>Stats:</strong><ul>';  //titeln
            foreach ($contents['stats'] as $stat) {  // Hämtar statistiken från api content
                echo '<li>' . ucfirst($stat['stat']['name']) . ': ' . $stat['base_stat'] . '</li>'; 
            }
            echo '</ul></p>';
    
             // Visar en lista på Pokémon-rörelser (där max 5st skall visas)
            echo '<p><strong>Moves:</strong><ul>';  //titeln 
            $moves = array_slice($contents['moves'], 0, 5); // 0-5 st av dess rörelser.
            foreach ($moves as $move) {  //För varje moves så går det in som move
                echo '<li>' . strip_tags($move['move']['name']) . '</li>';  //Nu när vi fått moves till move, så ska det hämtas
            }
            echo '</ul></p>';
    
            echo '</div>'; // Vi stänger hela pokemon-info-divet.
            echo '</div>'; //samma här nere. stänger pokemon card divet
        }
    
        // Stänger widgetens wrapper.
        echo $after_widget;
    }    
// UPdate-  vi ska nu uppdatera widgetens inställningar
    public function update($new_instance, $old_instance) {
        $instance = $old_instance; // vi ska behålla de gamla värdet
        $instance['title'] = isset($new_instance['title']) ? wp_strip_all_tags($new_instance['title']) : '';
        return $instance;
    }
// Skapar ett form för widgeten i adminpanelen.
    public function form($instance) {
        $title = isset($instance['title']) ? esc_attr($instance['title']) : ''; //Titeln hämtas eller sätter en tom
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>">Widget Title:</label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        <?php
    }
}
