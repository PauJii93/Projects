// App.js
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './screens/HomeScreen';
import PCListScreen from './screens/PCListScreen';
import PCDetailScreen from './screens/PCDetailScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="PC List" component={PCListScreen} />
        <Stack.Screen name="PC Details" component={PCDetailScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
