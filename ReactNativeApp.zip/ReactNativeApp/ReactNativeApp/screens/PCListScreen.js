import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Image } from 'react-native';
import axios from 'axios';
import chungusImage from '../assets/chungus.jpeg';

export default function PCListScreen({ navigation }) {
    const [quote, setQuote] = useState('');
    const [pcs, setPcs] = useState([]);
    const [funFact, setFunFact] = useState('');

    // Hämta citat och PCs från API
    useEffect(() => {
        // Slumpmässigt programmeringscitat
        axios.get('https://programming-quotesapi.vercel.app/api/random')
            .then(response => setQuote(response.data.en + ' — ' + response.data.author))
            .catch(() => setQuote("“Code is like humor. When you have to explain it, it’s bad.” — Cory House"));


        // Rolig info: random tech-fakta
        const facts = [
            "The first computer bug was an actual moth.",
            "CTRL + ALT + DEL was invented by accident.",
            "PCs used to be sold in kits you built yourself.",
            "You blink less when using a computer!",
            "Bill Gates' house was designed using a Mac."
        ];
        const randomFact = facts[Math.floor(Math.random() * facts.length)];
        setFunFact(randomFact);
    }, []);

    return (
        <View style={styles.container}>
            <Image
                source={chungusImage}
                style={styles.image}
                resizeMode="contain"
                onError={() => console.log("Image failed to load")}
            />
            <Text style={styles.funFact}>💡 {funFact}</Text>

            {/* Slumpmässigt programmeringscitat */}
            {quote ? (
                <View style={styles.quoteBox}>
                    <Text style={styles.quoteText}>💬 {quote}</Text>
                </View>
            ) : (
                <Text style={styles.empty}>Loading quote...</Text>
            )}

            {/* Lista med PCs */}
            {pcs.length > 0 ? (
                pcs.map(item => (
                    <View key={item.id} style={styles.pcItem}>
                        <Text>{item.name}</Text>
                    </View>
                ))
            ) : (
                <Text style={styles.empty}></Text>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 10,
        backgroundColor: '#e3f2fd', // Mjuk blå färg
    },
    image: {
        width: '100%',
        height: 200,
        marginBottom: 10,
        borderRadius: 12,
    },
    funFact: {
        fontSize: 16,
        fontStyle: 'italic',
        marginBottom: 15,
        textAlign: 'center',
        color: '#37474F',
    },
    quoteBox: {
        marginTop: 20,
        backgroundColor: '#fff3e0',
        padding: 16,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 4,
        elevation: 3,
    },
    quoteText: {
        fontSize: 16,
        fontStyle: 'italic',
        color: '#6d4c41',
        textAlign: 'center',
    },
    empty: {
        textAlign: 'center',
        marginTop: 20,
        color: '#888',
        fontSize: 16,
    },
    pcItem: {
        backgroundColor: '#ffffff',
        marginBottom: 10,
        padding: 15,
        borderRadius: 8,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowOffset: { width: 0, height: 2 },
        shadowRadius: 4,
        elevation: 3,
    }
});
