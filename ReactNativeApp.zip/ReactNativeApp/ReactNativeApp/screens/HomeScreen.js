import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';

export default function HomeScreen({ navigation }) {
    return (
        <View style={styles.container}>
            <Image
                source={require('../assets/jake.jpg')} // kontrollera att sökvägen stämmer
                style={styles.image}
                resizeMode="contain"
            />

            <Text style={styles.title}>Välkommen till min ReactNative app!</Text>

            <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate('PC List')}
            >
                <Text style={styles.buttonText}>More info</Text>
            </TouchableOpacity>

            <View style={{ height: 15 }} />

            <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate('PC Details')}
            >
                <Text style={styles.buttonText}>Go to PC Details</Text>
            </TouchableOpacity>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
        backgroundColor: '#f0f8ff',
    },
    image: {
        width: 120,
        height: 120,
        marginBottom: 30,
        borderRadius: 60,
        borderWidth: 2,
        borderColor: '#ccc',
    },
    title: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#2a2a72',
        marginBottom: 30,
        textShadowColor: 'rgba(0, 0, 0, 0.2)',
        textShadowOffset: { width: 1, height: 1 },
        textShadowRadius: 2,
        textAlign: 'center',
    },
    button: {
        backgroundColor: '#4682B4',
        paddingVertical: 12,
        paddingHorizontal: 25,
        borderRadius: 25,
        elevation: 3,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 3,
    },
    buttonText: {
        color: 'white',
        fontSize: 16,
        fontWeight: '600',
    },
});
