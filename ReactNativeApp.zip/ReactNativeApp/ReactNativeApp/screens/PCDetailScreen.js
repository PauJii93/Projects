import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, ActivityIndicator, StyleSheet, Alert } from 'react-native';

export default function PCDetailScreen() {
    const [loading, setLoading] = useState(true);
    const [pcList, setPcList] = useState([]);

    useEffect(() => {
        const getPCs = async () => {
            try {
                const response = await fetch('http://localhost:3000/PC');
                const json = await response.json();
                setPcList(json);
            } catch (error) {
                console.error(error);
                Alert.alert('Fel', 'Kunde inte hämta PC-data');
            } finally {
                setLoading(false);
            }
        };

        getPCs();
    }, []);

    const renderItem = ({ item }) => (
        <View style={styles.pcItem}>
            <Text style={styles.pcTitle}>{item.brand} {item.model}</Text>
            <Text style={styles.pcText}>Processor: {item.processor}</Text>
            <Text style={styles.pcText}>Grafikkort: {item.graphicscard}</Text>
            <Text style={styles.pcText}>Pris: {item.price} kr</Text>
        </View>
    );

    if (loading) {
        return (
            <View style={styles.centered}>
                <ActivityIndicator size="large" color="#1976d2" />
                <Text style={styles.loadingText}>Laddar PC-data...</Text>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <FlatList
                data={pcList}
                renderItem={renderItem}
                keyExtractor={(item, index) => index.toString()}
                contentContainerStyle={{ paddingBottom: 20 }}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        padding: 16,
        backgroundColor: '#e3f2fd',
    },
    pcItem: {
        marginBottom: 16,
        padding: 16,
        borderRadius: 16,
        backgroundColor: '#ffffff',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 3 },
        shadowOpacity: 0.2,
        shadowRadius: 4,
        elevation: 5,
    },
    pcTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        marginBottom: 8,
        color: '#0d47a1',
    },
    pcText: {
        fontSize: 16,
        color: '#333',
        marginBottom: 4,
    },
    centered: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#e3f2fd',
    },
    loadingText: {
        marginTop: 12,
        fontSize: 16,
        color: '#0d47a1',
    },
});
